﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace currency_converter_user_control_
{
    
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            DropDownList1.Items.Clear();
            DropDownList2.Items.Clear();

            String[] curr = { "€ (Euro)", "£ (Ponds)", "$ (US Doller)"
                                  ,"£ (United Kingdom)", "₺ (Turkey)","₦ (Nigeria)"};

            DropDownList1.Items.Add("----Select----");
            DropDownList1.Items.Add("₹ (Indian rupees)");
           


            foreach (String s in curr)
            {
                DropDownList2.Items.Add(s);
            }
        }
        double convertedamount;
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            String currency = Convert.ToString(DropDownList2.SelectedItem);
            double amount = Convert.ToDouble(TextBox1.Text);
            double value;
            if(DropDownList1.SelectedItem.Equals("₹ (Indian rupees)") && DropDownList2.SelectedItem.Equals("€ (Euro)") )
            {
                value = 0.011;
                convertedamount = value * amount;
                Button2.Text = convertedamount.ToString();
            }

           else if (DropDownList1.SelectedItem.Equals("₹ (Indian rupees)") && DropDownList2.SelectedItem.Equals("£ (Ponds)"))
            {
                value = 0.010;
                convertedamount = value * amount;
                Button2.Text = convertedamount.ToString();
            }

            else if (DropDownList1.SelectedItem.Equals("₹ (Indian rupees)") && DropDownList2.SelectedItem.Equals("$ (US Doller)"))
            {
                value = 70;
                convertedamount = value * amount;
                Button2.Text = convertedamount.ToString();
            }

            else if (DropDownList1.SelectedItem.Equals("₹ (Indian rupees)") && DropDownList2.SelectedItem.Equals("£ (United Kingdom)"))
            {
                value = 0.010;
                convertedamount = value * amount;
                Button2.Text = convertedamount.ToString();
            }

            else if (DropDownList1.SelectedItem.Equals("₹ (Indian rupees)") && DropDownList2.SelectedItem.Equals("₺ (Turkey)"))
            {
                value = 0.11;
                convertedamount = value * amount;
                Button2.Text = convertedamount.ToString();
            }
            else if (DropDownList1.SelectedItem.Equals("₹ (Indian rupees)") && DropDownList2.SelectedItem.Equals("₦ (Nigeria)"))
            {
                value = 5.12;
                convertedamount = value * amount;
                Button2.Text = convertedamount.ToString();
            }
               
            else
            {
                Response.Write("Enter Valid Data");
            }
                                  
                   
            }
            
        }
    }
