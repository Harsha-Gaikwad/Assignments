﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Filetext
{
    public partial class Form1 : Form
    {
        FileStream fs;
        StreamWriter sw;
        StreamReader sr;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            int empid = Convert.ToInt32(textBox1.Text);
            String empname = textBox2.Text;
            int salary = Convert.ToInt32(textBox3.Text);

            fs = new FileStream(@"C:\Users\test\Documents\demo.txt", FileMode.Append, FileAccess.Write);
            if (fs == null)
            {
                MessageBox.Show("sorry... file not found...");
            }
            else
            {
                sw = new StreamWriter(fs);
                sw.Write("\n"+empid + " " + empname + " " + salary+"\n");
                MessageBox.Show(" Data inserted successfully...");
            }
            sw.Close();
            fs.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            fs = new FileStream(@"C:\Users\test\Documents\demo.txt", FileMode.Open, FileAccess.Read);
            if (fs == null)
            {
                MessageBox.Show("File not Found...");
            }
            else
            {
                sr = new StreamReader(fs);
                richTextBox1.Text = sr.ReadToEnd();
                
            }
            sr.Close();
            fs.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox1.Focus();
        }
    }
}
